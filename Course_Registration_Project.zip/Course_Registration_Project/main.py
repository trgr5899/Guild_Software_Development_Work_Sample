from website import create_app

app=create_app()

#only if we run this line this line will run, not if it is imported
if __name__=='__main__':
    #this means everytime we add code the website will be re compiled
    app.run(debug=True)
