from flask import Blueprint, render_template,request, flash, redirect, url_for
from .models import Students, Course
from werkzeug.security import  generate_password_hash, check_password_hash
from . import db
from flask_login import login_user, login_required,logout_user, current_user

auth = Blueprint('auth',__name__)

@auth.route('/courses',methods=['GET','POST'])
@login_required
def courses():
    classes=[False,False,False,False,False,False,False]
    for i in range(1,8):
        if Course.query.filter_by(course_id=i).first():
            for currStudent in Course.query.filter_by(course_id=i).first().enrolled:
                if currStudent.id==current_user.id:
                    classes[i-1]=True
    return render_template("courses.html",user=current_user,classes=classes)


@auth.route('/register',methods=['GET','POST'])
@login_required
def register():
    classes=[False,False,False,False,False,False,False]
    for i in range(1,8):
        if Course.query.filter_by(course_id=i).first():
            for currStudent in Course.query.filter_by(course_id=i).first().enrolled:
                if currStudent.id==current_user.id:
                    classes[i-1]=True
    if 'class1' in request.form:
        course1=Course.query.filter_by(course_id=1).first()
        course1.enrolled.append(current_user)
        db.session.commit()
        classes[0]=True
        return render_template("register.html",user=current_user,classes=classes)
    elif 'class2' in request.form:
        course2=Course.query.filter_by(course_id=2).first()
        course2.enrolled.append(current_user)
        db.session.commit()
        classes[1]=True
        return render_template("register.html",user=current_user,classes=classes)
    elif 'class3' in request.form:
        course2=Course.query.filter_by(course_id=3).first()
        course2.enrolled.append(current_user)
        db.session.commit()
        classes[2]=True
        return render_template("register.html",user=current_user,classes=classes)
    elif 'class4' in request.form:
        course2=Course.query.filter_by(course_id=4).first()
        course2.enrolled.append(current_user)
        db.session.commit()
        classes[3]=True
        return render_template("register.html",user=current_user,classes=classes)
    elif 'class5' in request.form:
        course2=Course.query.filter_by(course_id=5).first()
        course2.enrolled.append(current_user)
        db.session.commit()
        classes[4]=True
        return render_template("register.html",user=current_user,classes=classes)
    elif 'class6' in request.form:
        course2=Course.query.filter_by(course_id=6).first()
        course2.enrolled.append(current_user)
        db.session.commit()
        classes[5]=True
        return render_template("register.html",user=current_user,classes=classes)
    elif 'class7' in request.form:
        course2=Course.query.filter_by(course_id=7).first()
        course2.enrolled.append(current_user)
        db.session.commit()
        classes[6]=True
        return render_template("register.html",user=current_user,classes=classes)
    elif 'drop1' in request.form:
        course2=Course.query.filter_by(course_id=1).first()
        course2.enrolled.remove(current_user)
        db.session.commit()
        classes[0]=False
        return render_template("register.html",user=current_user,classes=classes)
        return render_template("register.html",user=current_user, classes=classes)
    elif 'drop2' in request.form:
        course2=Course.query.filter_by(course_id=2).first()
        course2.enrolled.remove(current_user)
        db.session.commit()
        classes[1]=False
        return render_template("register.html",user=current_user,classes=classes)
    elif 'drop3' in request.form:
        course2=Course.query.filter_by(course_id=3).first()
        course2.enrolled.remove(current_user)
        db.session.commit()
        classes[2]=False
        return render_template("register.html",user=current_user,classes=classes)
    elif 'drop4' in request.form:
        course2=Course.query.filter_by(course_id=4).first()
        course2.enrolled.remove(current_user)
        db.session.commit()
        classes[3]=False
        return render_template("register.html",user=current_user,classes=classes)
    elif 'drop5' in request.form:
        course2=Course.query.filter_by(course_id=5).first()
        course2.enrolled.remove(current_user)
        db.session.commit()
        classes[4]=False
        return render_template("register.html",user=current_user,classes=classes)
    elif 'drop6' in request.form:

        course2=Course.query.filter_by(course_id=6).first()
        course2.enrolled.remove(current_user)
        db.session.commit()
        classes[5]=False
        return render_template("register.html",user=current_user,classes=classes)
    elif 'drop7' in request.form:
        course2=Course.query.filter_by(course_id=7).first()
        course2.enrolled.remove(current_user)
        db.session.commit()
        classes[6]=False
        return render_template("register.html",user=current_user,classes=classes)
    return render_template("register.html",user=current_user, classes=classes)


@auth.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        email=request.form.get('email')
        password=request.form.get('password')

        student=Students.query.filter_by(email=email).first()

        if student:
            if check_password_hash(student.password,password):
                flash('Logged in successfully',category='success')
                login_user(student,remember=True)
                return redirect(url_for('views.home'))
            else:
                flash('incorrect Password',category='error')
        else:
            flash('Email does not exist', category='error')



    return render_template("login.html",user=current_user)
@auth.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.login'))



@auth.route('/sign-up',methods=['GET','POST'])
def sign_up():
    if request.method=='POST':
        email= request.form.get('email')
        firstName=request.form.get('firstName')
        password1=request.form.get('password1')
        password2=request.form.get('password2')

        student=Students.query.filter_by(email=email).first()
        if student:
            flash('Email already exists', category='error')
        elif len(email) < 4:
            flash('Email needs atleast 4 characters',category='error')
        elif len(firstName)< 2:
            flash('First name needs atleast 2 characters',category='error')
        elif password1 != password2:
            flash('The passwords do not match',category='error')
        elif len(password1) < 7:
            flash('The passwords needs to be atleast 7 letters ',category='error')
        else:
            new_student=Students(email=email,first_name=firstName,password=generate_password_hash(password1, method='sha256'))#create new user
            db.session.add(new_student)
            db.session.commit()
            check=Course.query.filter_by(course_id=1).first()
            if check:
                pass
            else:

                course1=Course(course_id=1,courseName="CSCI Algorithms",time="4:30 pm to 6 pm on Tuesday")
                course2=Course(course_id=2,courseName="CSCI Discrete Math",time="4:30 pm to 6 pm on Tuesday")
                course3=Course(course_id=3,courseName="CSCI Computer Systems",time="4:30 pm to 6 pm on Tuesday")
                course4=Course(course_id=4,courseName="CSCI Principes of Programming Languages",time="4:30 pm to 6 pm on Tuesday")
                course5=Course(course_id=5,courseName="CSCI Robotics",time="4:30 pm to 6 pm on Tuesday")
                course6=Course(course_id=6,courseName="CSCI Intro to AI",time="4:30 pm to 6 pm on Tuesday")
                course7=Course(course_id=7,courseName="CSCI Linear Algebra",time="4:30 pm to 6 pm on Tuesday")
                db.session.add(course1)
                db.session.add(course2)
                db.session.add(course3)
                db.session.add(course4)
                db.session.add(course5)
                db.session.add(course6)
                db.session.add(course7)
                db.session.commit()

            flash('Thanks for signing up',category='success')
            login_user(new_student,remember=True)
            return redirect(url_for('views.home'))

    return render_template("sign_up.html", user=current_user)
