from . import db #from this folder import our database
from flask_login import UserMixin
from sqlalchemy.sql import func

roster=db.Table('roster',
db.Column('student_id',db.Integer,db.ForeignKey('students.id')),
db.Column('course_id',db.Integer,db.ForeignKey('course.course_id'))
)

class Course(db.Model):
    course_id = db.Column(db.Integer,primary_key=True)#primary key
    courseName=db.Column(db.String(150),unique=True)
    time=db.Column(db.String(150))

class Students(db.Model,UserMixin):
    id = db.Column(db.Integer,primary_key=True)#primary key
    email=db.Column(db.String(150),unique=True)
    password=db.Column(db.String(150))
    first_name=db.Column(db.String(150))
    classes=db.relationship('Course', secondary=roster, backref=db.backref('enrolled', lazy= 'dynamic'))
