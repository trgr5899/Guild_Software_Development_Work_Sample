from flask import Blueprint, render_template, request, flash, jsonify
from flask_login import login_required, current_user
from .models import Students, Course
from . import db
import json

views = Blueprint('views',__name__)


@views.route('/', methods=['GET', 'POST'])
@login_required
def home():
    classes=[False,False,False,False,False,False,False]
    for i in range(1,8):
        if Course.query.filter_by(course_id=i).first():
            for currStudent in Course.query.filter_by(course_id=i).first().enrolled:
                if currStudent.id==current_user.id:
                    classes[i-1]=True
    if 'register' in request.form:
        return render_template("register.html",user=current_user,classes=classes)
    elif 'yourClass' in request.form:
        return render_template("courses.html",user=current_user, classes=classes)
    return render_template("home.html",user=current_user, classes=classes)
